import java.util.List;

public interface Item {
	public String read();
	public String searchName(String name);
	public String readCategory(String category);
}
