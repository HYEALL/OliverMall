
public interface Order {
	public String readAll();
	public String read(String orderno);
}
