
public class Olivermall {
	public static void main(String[] args) {
		//new HomeFrame();
		//new ReviewFrame();
		new OrderFrame();
	}
}
