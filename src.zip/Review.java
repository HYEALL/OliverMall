
public interface Review {
	public String searchItemNo(int no);
}
